﻿Imports System.Collections
Public Class Form1

    Private sMyStack As New Stack 'Our Stack Object
    Public strTemp As String
  

   

    Public Sub DisplayValues(ByVal MyStackCollection As IEnumerable)

        ListBox2.Items.Clear()
        Dim MyStackEnumerator As IEnumerator = MyStackCollection.GetEnumerator()

        While MyStackEnumerator.MoveNext()
            ListBox2.Items.Add(MyStackEnumerator.Current.ToString()) 'Display current item
        End While


    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        DisplayValues(sMyStack)
    End Sub
    Dim nr As Integer
    Dim inaltime As Integer = 75
    Dim latime As Integer = 23
    Private Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click

        If nr < 8 Then
            strTemp = InputBox("Introduceti elementul dorit!")
            If Not String.IsNullOrEmpty(strTemp) Then
                Try
                    sMyStack.Push(strTemp)
                    Dim buttons As Button() = {stack1, stack2, stack3, stack4, stack5, stack6, stack7, stack8}
                    If nr < 8 Then
                        buttons(nr).Size = New Size(inaltime, latime)
                        inaltime = inaltime - 1
                        latime = latime - 1
                        buttons(nr).Visible = True
                        buttons(nr).Text = strTemp
                        nr = nr + 1
                    
                    End If
                Catch ex As Exception
                    MessageBox.Show("Stack is full")
                End Try
            Else
                MessageBox.Show("Nu ai introdus element!")

            End If
        Else
            MessageBox.Show("Stack is full")
        End If

        



    End Sub

    Private Sub Button4_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button4.Click

        Try
            sMyStack.Pop()
            Dim buttons As Button() = {stack1, stack2, stack3, stack4, stack5, stack6, stack7, stack8}

            If nr >= 0 Then
                nr = nr - 1
                buttons(nr).Visible = False

            End If
        Catch ex As Exception
            MessageBox.Show("Stack is empty!")
        End Try


    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        ListBox2.Items.Clear()
        ListBox2.Items.Add(sMyStack.Peek())
    End Sub
    Dim y As Integer
    Private Sub RectangleShape1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub LineShape1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LineShape1.Click

    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles stack8.Click
        If stack8.Visible = True Then
            If stack7.Location = New Point(332, 224) Then
                MessageBox.Show("Error")
            ElseIf stack8.Location = New Point(478, 36) Then
                stack8.Location = New Point(332, 256)
            Else
                stack8.Location = New Point(478, 36)
            End If
        ElseIf stack8.Location = New Point(478, 36) Then
            stack8.Location = New Point(332, 256)
        Else
            stack8.Location = New Point(478, 36)
        End If

    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles stack6.Click
        If stack7.Visible = True Then
            If stack7.Location = New Point(478, 67) Then
                MessageBox.Show("Error")
            ElseIf stack5.Location = New Point(332, 162) Then
                MessageBox.Show("Error")
            ElseIf stack6.Location = New Point(478, 98) Then
                stack6.Location = New Point(332, 194)
            ElseIf stack5.Location = New Point(332, 159) Then
                MessageBox.Show("Error")
            Else
                stack6.Location = New Point(478, 98)
            End If
        ElseIf stack6.Location = New Point(478, 98) Then
            stack6.Location = New Point(332, 194)
        ElseIf stack5.Location = New Point(332, 159) Then
            MessageBox.Show("Error")
        Else
            stack6.Location = New Point(478, 98)
        End If

    End Sub

    Private Sub OvalShape1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OvalShape1.Click

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Opacity = 0.95
    End Sub

    Private Sub stack3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles stack3.Click
        If stack4.Visible = True Then
            If stack4.Location = New Point(478, 159) Then
                MessageBox.Show("Error")
            ElseIf stack3.Location = New Point(478, 190) Then
                stack3.Location = New Point(332, 98)
            ElseIf stack2.Location = New Point(332, 67) Then
                MessageBox.Show("Error")
            Else
                stack3.Location = New Point(478, 190)
            End If
        ElseIf stack3.Location = New Point(478, 190) Then
            stack3.Location = New Point(332, 98)
        ElseIf stack2.Location = New Point(332, 67) Then
            MessageBox.Show("Error")
        Else
            stack3.Location = New Point(478, 190)
        End If
    End Sub

    Private Sub stack7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles stack7.Click
        If stack8.Visible = True Then
            If stack8.Location = New Point(478, 36) Then
                MessageBox.Show("Error")
            ElseIf stack6.Location = New Point(332, 194) Then
                MessageBox.Show("Error")
            ElseIf stack7.Location = New Point(478, 67) Then
                stack7.Location = New Point(332, 224)
            Else
                stack7.Location = New Point(478, 67)
            End If
        ElseIf stack7.Location = New Point(478, 67) Then
            stack7.Location = New Point(332, 224)
        Else
            stack7.Location = New Point(478, 67)
        End If
    End Sub

    Private Sub ListBox2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox2.SelectedIndexChanged

    End Sub

    Private Sub stack5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles stack5.Click
        If stack6.Visible = True Then
            If stack6.Location = New Point(478, 98) Then
                MessageBox.Show("Error")
            ElseIf stack5.Location = New Point(332, 164) Then
                MessageBox.Show("Error")
            ElseIf stack5.Location = New Point(478, 128) Then
                stack5.Location = New Point(332, 159)
            ElseIf stack4.Location = New Point(332, 128) Then
                MessageBox.Show("Error")
            Else
                stack5.Location = New Point(478, 128)
            End If
        ElseIf stack5.Location = New Point(478, 128) Then
            stack5.Location = New Point(332, 159)
        ElseIf stack4.Location = New Point(332, 128) Then
            MessageBox.Show("Error")
        Else
            stack5.Location = New Point(478, 128)
        End If
    End Sub

    Private Sub stack4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles stack4.Click
        If stack5.Visible = True Then
            If stack5.Location = New Point(478, 128) Then
                MessageBox.Show("Error")
            ElseIf stack4.Location = New Point(478, 159) Then
                stack4.Location = New Point(332, 128)
            ElseIf stack3.Location = New Point(332, 98) Then
                MessageBox.Show("Error")
            Else
                stack4.Location = New Point(478, 159)
            End If
        ElseIf stack4.Location = New Point(478, 159) Then
            stack4.Location = New Point(332, 128)
        ElseIf stack3.Location = New Point(332, 98) Then
            MessageBox.Show("Error")
        Else
            stack4.Location = New Point(478, 159)
        End If
    End Sub

    Private Sub stack2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles stack2.Click
        If stack3.Visible = True Then
            If stack3.Location = New Point(478, 190) Then
                MessageBox.Show("Error")
            ElseIf stack2.Location = New Point(478, 221) Then
                stack2.Location = New Point(332, 67)
            ElseIf stack1.Location = New Point(332, 36) Then
                MessageBox.Show("Error")
            Else
                stack2.Location = New Point(478, 221)
            End If
        ElseIf stack2.Location = New Point(478, 221) Then
            stack2.Location = New Point(332, 67)
        ElseIf stack1.Location = New Point(332, 36) Then
            MessageBox.Show("Error")
        Else
            stack2.Location = New Point(478, 221)
        End If

    End Sub

    Private Sub stack1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles stack1.Click
        If stack2.Visible = True Then
            If stack2.Location = New Point(478, 221) Then
                MessageBox.Show("Error")
            ElseIf stack1.Location = New Point(478, 255) Then
                stack1.Location = New Point(332, 36)
            Else
                stack1.Location = New Point(478, 255)
            End If
        ElseIf stack1.Location = New Point(478, 255) Then
            stack1.Location = New Point(332, 36)
        Else
            stack1.Location = New Point(478, 255)
        End If

    End Sub
End Class
