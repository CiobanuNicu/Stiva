﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.stack1 = New System.Windows.Forms.Button()
        Me.stack2 = New System.Windows.Forms.Button()
        Me.stack3 = New System.Windows.Forms.Button()
        Me.stack4 = New System.Windows.Forms.Button()
        Me.stack5 = New System.Windows.Forms.Button()
        Me.stack6 = New System.Windows.Forms.Button()
        Me.stack7 = New System.Windows.Forms.Button()
        Me.stack8 = New System.Windows.Forms.Button()
        Me.ShapeContainer1 = New Microsoft.VisualBasic.PowerPacks.ShapeContainer()
        Me.OvalShape1 = New Microsoft.VisualBasic.PowerPacks.OvalShape()
        Me.LineShape1 = New Microsoft.VisualBasic.PowerPacks.LineShape()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        '
        'ListBox2
        '
        Me.ListBox2.BackColor = System.Drawing.Color.Cyan
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.ItemHeight = 14
        Me.ListBox2.Location = New System.Drawing.Point(14, 44)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(177, 130)
        Me.ListBox2.TabIndex = 3
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.SystemColors.InactiveBorder
        Me.Button3.BackgroundImage = CType(resources.GetObject("Button3.BackgroundImage"), System.Drawing.Image)
        Me.Button3.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(51, 190)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(104, 25)
        Me.Button3.TabIndex = 4
        Me.Button3.Text = "Show Values"
        Me.ToolTip1.SetToolTip(Me.Button3, "Afiseaza elementele stivei")
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button1.BackgroundImage = CType(resources.GetObject("Button1.BackgroundImage"), System.Drawing.Image)
        Me.Button1.Location = New System.Drawing.Point(217, 44)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(87, 25)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "Push"
        Me.ToolTip1.SetToolTip(Me.Button1, "Adaugare unui element " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " in stiva")
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button4.BackgroundImage = CType(resources.GetObject("Button4.BackgroundImage"), System.Drawing.Image)
        Me.Button4.Location = New System.Drawing.Point(217, 98)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(87, 25)
        Me.Button4.TabIndex = 6
        Me.Button4.Text = "Pop"
        Me.ToolTip1.SetToolTip(Me.Button4, "Eliminarea primului element din stiva")
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button5.BackgroundImage = CType(resources.GetObject("Button5.BackgroundImage"), System.Drawing.Image)
        Me.Button5.Location = New System.Drawing.Point(217, 150)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(87, 25)
        Me.Button5.TabIndex = 7
        Me.Button5.Text = "Peek"
        Me.ToolTip1.SetToolTip(Me.Button5, "Afisarea primului element din stiva")
        Me.Button5.UseVisualStyleBackColor = False
        '
        'stack1
        '
        Me.stack1.BackColor = System.Drawing.SystemColors.InfoText
        Me.stack1.BackgroundImage = CType(resources.GetObject("stack1.BackgroundImage"), System.Drawing.Image)
        Me.stack1.ForeColor = System.Drawing.Color.LimeGreen
        Me.stack1.Location = New System.Drawing.Point(478, 255)
        Me.stack1.Name = "stack1"
        Me.stack1.Size = New System.Drawing.Size(87, 25)
        Me.stack1.TabIndex = 8
        Me.stack1.Text = "Stack1"
        Me.stack1.UseVisualStyleBackColor = False
        Me.stack1.Visible = False
        '
        'stack2
        '
        Me.stack2.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.stack2.BackgroundImage = CType(resources.GetObject("stack2.BackgroundImage"), System.Drawing.Image)
        Me.stack2.ForeColor = System.Drawing.Color.LimeGreen
        Me.stack2.Location = New System.Drawing.Point(478, 221)
        Me.stack2.Name = "stack2"
        Me.stack2.Size = New System.Drawing.Size(87, 25)
        Me.stack2.TabIndex = 9
        Me.stack2.Text = "Stack2"
        Me.stack2.UseVisualStyleBackColor = False
        Me.stack2.Visible = False
        '
        'stack3
        '
        Me.stack3.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.stack3.BackgroundImage = CType(resources.GetObject("stack3.BackgroundImage"), System.Drawing.Image)
        Me.stack3.ForeColor = System.Drawing.Color.LimeGreen
        Me.stack3.Location = New System.Drawing.Point(478, 190)
        Me.stack3.Name = "stack3"
        Me.stack3.Size = New System.Drawing.Size(87, 25)
        Me.stack3.TabIndex = 10
        Me.stack3.Text = "Stack3"
        Me.stack3.UseVisualStyleBackColor = False
        Me.stack3.Visible = False
        '
        'stack4
        '
        Me.stack4.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.stack4.BackgroundImage = CType(resources.GetObject("stack4.BackgroundImage"), System.Drawing.Image)
        Me.stack4.ForeColor = System.Drawing.Color.LimeGreen
        Me.stack4.Location = New System.Drawing.Point(478, 159)
        Me.stack4.Name = "stack4"
        Me.stack4.Size = New System.Drawing.Size(87, 25)
        Me.stack4.TabIndex = 11
        Me.stack4.Text = "Stack4"
        Me.stack4.UseVisualStyleBackColor = False
        Me.stack4.Visible = False
        '
        'stack5
        '
        Me.stack5.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.stack5.BackgroundImage = CType(resources.GetObject("stack5.BackgroundImage"), System.Drawing.Image)
        Me.stack5.Font = New System.Drawing.Font("Californian FB", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.stack5.ForeColor = System.Drawing.Color.LimeGreen
        Me.stack5.Location = New System.Drawing.Point(478, 128)
        Me.stack5.Name = "stack5"
        Me.stack5.Size = New System.Drawing.Size(87, 25)
        Me.stack5.TabIndex = 12
        Me.stack5.Text = "Stack5"
        Me.stack5.UseVisualStyleBackColor = False
        Me.stack5.Visible = False
        '
        'stack6
        '
        Me.stack6.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.stack6.BackgroundImage = CType(resources.GetObject("stack6.BackgroundImage"), System.Drawing.Image)
        Me.stack6.Font = New System.Drawing.Font("Californian FB", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.stack6.ForeColor = System.Drawing.Color.LimeGreen
        Me.stack6.Location = New System.Drawing.Point(478, 98)
        Me.stack6.Name = "stack6"
        Me.stack6.Size = New System.Drawing.Size(87, 25)
        Me.stack6.TabIndex = 13
        Me.stack6.Text = "Stack6"
        Me.stack6.UseVisualStyleBackColor = False
        Me.stack6.Visible = False
        '
        'stack7
        '
        Me.stack7.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.stack7.BackgroundImage = CType(resources.GetObject("stack7.BackgroundImage"), System.Drawing.Image)
        Me.stack7.Font = New System.Drawing.Font("Californian FB", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.stack7.ForeColor = System.Drawing.Color.LimeGreen
        Me.stack7.Location = New System.Drawing.Point(478, 67)
        Me.stack7.Name = "stack7"
        Me.stack7.Size = New System.Drawing.Size(87, 25)
        Me.stack7.TabIndex = 14
        Me.stack7.Text = "Stack7"
        Me.stack7.UseVisualStyleBackColor = False
        Me.stack7.Visible = False
        '
        'stack8
        '
        Me.stack8.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.stack8.BackgroundImage = CType(resources.GetObject("stack8.BackgroundImage"), System.Drawing.Image)
        Me.stack8.Font = New System.Drawing.Font("Californian FB", 6.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.stack8.ForeColor = System.Drawing.Color.LimeGreen
        Me.stack8.Location = New System.Drawing.Point(478, 36)
        Me.stack8.Name = "stack8"
        Me.stack8.Size = New System.Drawing.Size(87, 25)
        Me.stack8.TabIndex = 15
        Me.stack8.Text = "Stack8"
        Me.stack8.UseVisualStyleBackColor = False
        Me.stack8.Visible = False
        '
        'ShapeContainer1
        '
        Me.ShapeContainer1.Location = New System.Drawing.Point(0, 0)
        Me.ShapeContainer1.Margin = New System.Windows.Forms.Padding(0)
        Me.ShapeContainer1.Name = "ShapeContainer1"
        Me.ShapeContainer1.Shapes.AddRange(New Microsoft.VisualBasic.PowerPacks.Shape() {Me.OvalShape1, Me.LineShape1})
        Me.ShapeContainer1.Size = New System.Drawing.Size(639, 340)
        Me.ShapeContainer1.TabIndex = 16
        Me.ShapeContainer1.TabStop = False
        '
        'OvalShape1
        '
        Me.OvalShape1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.OvalShape1.BorderColor = System.Drawing.Color.Plum
        Me.OvalShape1.Location = New System.Drawing.Point(460, 248)
        Me.OvalShape1.Name = "OvalShape1"
        Me.OvalShape1.Size = New System.Drawing.Size(115, 63)
        '
        'LineShape1
        '
        Me.LineShape1.BorderColor = System.Drawing.SystemColors.HotTrack
        Me.LineShape1.Name = "LineShape1"
        Me.LineShape1.X1 = 512
        Me.LineShape1.X2 = 512
        Me.LineShape1.Y1 = 26
        Me.LineShape1.Y2 = 279
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightBlue
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(639, 340)
        Me.Controls.Add(Me.stack8)
        Me.Controls.Add(Me.stack7)
        Me.Controls.Add(Me.stack6)
        Me.Controls.Add(Me.stack5)
        Me.Controls.Add(Me.stack4)
        Me.Controls.Add(Me.stack3)
        Me.Controls.Add(Me.stack2)
        Me.Controls.Add(Me.stack1)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.ListBox2)
        Me.Controls.Add(Me.ShapeContainer1)
        Me.Font = New System.Drawing.Font("Californian FB", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.Indigo
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ListBox2 As System.Windows.Forms.ListBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents stack1 As System.Windows.Forms.Button
    Friend WithEvents stack2 As System.Windows.Forms.Button
    Friend WithEvents stack3 As System.Windows.Forms.Button
    Friend WithEvents stack4 As System.Windows.Forms.Button
    Friend WithEvents stack5 As System.Windows.Forms.Button
    Friend WithEvents stack6 As System.Windows.Forms.Button
    Friend WithEvents stack7 As System.Windows.Forms.Button
    Friend WithEvents stack8 As System.Windows.Forms.Button
    Friend WithEvents ShapeContainer1 As Microsoft.VisualBasic.PowerPacks.ShapeContainer
    Friend WithEvents LineShape1 As Microsoft.VisualBasic.PowerPacks.LineShape
    Friend WithEvents OvalShape1 As Microsoft.VisualBasic.PowerPacks.OvalShape
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip

End Class
